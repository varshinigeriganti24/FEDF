import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useEMR, DOCTORS } from "@/lib/emr-store";
import { downloadAll } from "@/lib/download";
import type { Appointment, MedicalRecord } from "@/lib/emr-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Healthcare EMR Portal" },
      { name: "description", content: "Patient registration, appointments, and electronic medical records." },
      { property: "og:title", content: "Healthcare EMR Portal" },
      { property: "og:description", content: "Patient registration, appointments, and electronic medical records." },
    ],
  }),
  component: EMRPortal,
});

type TabKey = "home" | "register" | "patient" | "appointment" | "doctor" | "records" | "admin";

const TAB_LABELS: { key: TabKey; label: string }[] = [
  { key: "home", label: "Home" },
  { key: "register", label: "Register" },
  { key: "patient", label: "Patient" },
  { key: "appointment", label: "Book" },
  { key: "doctor", label: "Doctor" },
  { key: "records", label: "Records" },
  { key: "admin", label: "Admin" },
];

function EMRPortal() {
  const [tab, setTab] = useState<TabKey>("home");

  return (
    <main className="min-h-screen bg-background">
      {/* Inline tab navigation */}
      <nav className="sticky top-0 z-50 border-b border-border bg-primary text-primary-foreground shadow-sm">
        <div className="container mx-auto flex flex-wrap items-center justify-between gap-3 px-4 py-3">
          <span className="text-lg font-semibold tracking-tight">🏥 Healthcare EMR Portal</span>
          <div className="flex flex-wrap gap-1">
            {TAB_LABELS.map((t) => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
                  tab === t.key ? "bg-white/20" : "hover:bg-white/15"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <div className="container mx-auto max-w-5xl px-4 py-10">
        {tab === "home" && <HomeTab onNavigate={setTab} />}
        {tab === "register" && <RegisterTab onNavigate={setTab} />}
        {tab === "patient" && <PatientTab onNavigate={setTab} />}
        {tab === "appointment" && <AppointmentTab onNavigate={setTab} />}
        {tab === "doctor" && <DoctorTab />}
        {tab === "records" && <RecordsTab />}
        {tab === "admin" && <AdminTab />}
      </div>
    </main>
  );
}

/* ───────── Home ───────── */
function HomeTab({ onNavigate }: { onNavigate: (t: TabKey) => void }) {
  const { appointments } = useEMR();
  const todays = [
    { time: "10:00 AM", patient: "Rahul Kumar", doctor: "Dr. Priya Sharma", dept: "Cardiology" },
    { time: "11:30 AM", patient: "Ananya Patel", doctor: "Dr. Rajesh Kumar", dept: "General Medicine" },
    { time: "02:00 PM", patient: "Rakesh Singh", doctor: "Dr. Anjali Reddy", dept: "Dermatology" },
  ];
  const ctas: Array<{ tab: TabKey; label: string; tone: string }> = [
    { tab: "register", label: "Patient Registration", tone: "bg-white text-primary hover:bg-white/90" },
    { tab: "patient", label: "Patient Dashboard", tone: "bg-amber-400 text-amber-950 hover:bg-amber-300" },
    { tab: "doctor", label: "Doctor Dashboard", tone: "bg-emerald-500 text-white hover:bg-emerald-400" },
    { tab: "records", label: "Medical Records", tone: "bg-sky-400 text-sky-950 hover:bg-sky-300" },
  ];

  return (
    <>
      <section className="rounded-3xl bg-gradient-to-br from-primary to-sky-500 px-4 py-16 text-primary-foreground text-center">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
          Healthcare Patient Registration &amp; EMR Portal
        </h1>
        <p className="mt-4 text-lg opacity-90">
          Manage patients, appointments and electronic medical records.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          {ctas.map((c) => (
            <button
              key={c.tab}
              onClick={() => onNavigate(c.tab)}
              className={`rounded-lg px-5 py-2.5 text-sm font-semibold shadow-md transition ${c.tone}`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </section>

      <section className="mt-8 rounded-2xl border border-border bg-card p-6 shadow-sm">
        <h2 className="text-2xl font-semibold text-card-foreground">Today&apos;s Appointments</h2>
        <ul className="mt-4 divide-y divide-border">
          {todays.map((t) => (
            <li key={t.time} className="flex flex-wrap items-center justify-between gap-2 py-3">
              <span className="font-mono text-sm text-muted-foreground">{t.time}</span>
              <span className="font-medium">{t.patient}</span>
              <span className="text-sm text-muted-foreground">→ {t.doctor}</span>
              <span className="rounded-full bg-secondary px-3 py-1 text-xs">{t.dept}</span>
            </li>
          ))}
        </ul>
        {appointments.length > 3 && (
          <p className="mt-3 text-sm text-muted-foreground">+ {appointments.length - 3} more scheduled</p>
        )}
      </section>
    </>
  );
}

/* ───────── Register ───────── */
function RegisterTab({ onNavigate }: { onNavigate: (t: TabKey) => void }) {
  const { setPatientName } = useEMR();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [msg, setMsg] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setPatientName(name);
    setMsg(`Patient ${name} registered successfully!`);
    setTimeout(() => onNavigate("patient"), 900);
  };

  return (
    <div className="mx-auto max-w-xl">
      <h1 className="text-3xl font-bold">Patient Registration</h1>
      <form onSubmit={submit} className="mt-6 space-y-4 rounded-2xl border border-border bg-card p-6 shadow-sm">
        <Field label="Full Name" value={name} onChange={setName} placeholder="John Doe" />
        <Field label="Email" value={email} onChange={setEmail} placeholder="john@example.com" type="email" />
        <Field label="Phone" value={phone} onChange={setPhone} placeholder="+91 98765 43210" />
        <button type="submit" className="w-full rounded-lg bg-primary px-4 py-2.5 font-medium text-primary-foreground shadow hover:bg-primary/90">
          Register
        </button>
        {msg && <p className="text-sm font-medium text-emerald-600">{msg}</p>}
      </form>
    </div>
  );
}

/* ───────── Patient ───────── */
function PatientTab({ onNavigate }: { onNavigate: (t: TabKey) => void }) {
  const { patientName, appointments } = useEMR();
  const cards = [
    { title: "Profile", body: patientName || "No patient registered yet." },
    { title: "Appointments", body: `${appointments.length} scheduled` },
    { title: "Medical Records", body: "View clinical history" },
  ];
  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-bold">Patient Dashboard</h1>
        <button
          onClick={() => onNavigate("appointment")}
          className="rounded-lg bg-emerald-500 px-4 py-2 text-sm font-medium text-white shadow hover:bg-emerald-400"
        >
          + Book Appointment
        </button>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        {cards.map((c) => (
          <div key={c.title} className="rounded-2xl border border-border bg-card p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
            <h3 className="text-lg font-semibold">{c.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{c.body}</p>
          </div>
        ))}
      </div>

      <section className="mt-8 rounded-2xl border border-border bg-card p-6 shadow-sm">
        <h2 className="text-xl font-semibold">My Appointments</h2>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-secondary text-secondary-foreground">
              <tr>
                {["Doctor", "Department", "Date", "Time", "Status"].map((h) => (
                  <th key={h} className="px-3 py-2 text-left font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {appointments.map((a, i) => (
                <tr key={i} className="border-t border-border">
                  <td className="px-3 py-2">{a.doctor}</td>
                  <td className="px-3 py-2">{a.department}</td>
                  <td className="px-3 py-2">{a.date}</td>
                  <td className="px-3 py-2">{a.time}</td>
                  <td className="px-3 py-2">
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${a.status === "Confirmed" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>
                      {a.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}

/* ───────── Appointment ───────── */
function AppointmentTab({ onNavigate }: { onNavigate: (t: TabKey) => void }) {
  const { addAppointment, patientName, setPatientName } = useEMR();
  const [name, setName] = useState(patientName);
  const [doctorIdx, setDoctorIdx] = useState<number>(-1);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (doctorIdx < 0 || !date || !time) return;
    const d = DOCTORS[doctorIdx];
    if (name) setPatientName(name);
    addAppointment({ doctor: d.name, department: d.dept, date, time, status: "Confirmed" });
    onNavigate("patient");
  };

  const inp = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";

  return (
    <div className="mx-auto max-w-xl">
      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <h1 className="text-2xl font-bold">Book Appointment</h1>
        <form onSubmit={submit} className="mt-5 space-y-4">
          <div>
            <label className="mb-1 block text-sm font-medium">Patient Name</label>
            <input className={inp} value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter patient name" />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">Department &amp; Doctor</label>
            <select value={doctorIdx} onChange={(e) => setDoctorIdx(Number(e.target.value))} className={inp}>
              <option value={-1}>Select Doctor</option>
              {DOCTORS.map((d, i) => (
                <option key={d.name} value={i}>{d.dept} — {d.name} ({d.hours})</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inp} />
            <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className={inp} />
          </div>
          <button type="submit" className="w-full rounded-lg bg-primary px-4 py-2.5 font-medium text-primary-foreground hover:bg-primary/90">
            Confirm Appointment
          </button>
        </form>
      </div>
    </div>
  );
}

/* ───────── Doctor ───────── */
function DoctorTab() {
  const { records, addRecord } = useEMR();
  const [patient, setPatient] = useState("");
  const [doctor, setDoctor] = useState("");
  const [diagnosis, setDiagnosis] = useState("");
  const [prescription, setPrescription] = useState("");
  const [treatment, setTreatment] = useState("");

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patient || !doctor) return;
    addRecord({ date: new Date().toLocaleDateString(), patient, doctor, diagnosis, prescription, treatment });
    setPatient(""); setDoctor(""); setDiagnosis(""); setPrescription(""); setTreatment("");
  };

  const inp = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";

  return (
    <>
      <h1 className="text-3xl font-bold">Doctor Dashboard</h1>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Stat label="Patients Treated" value={records.length} />
        <Stat label="Medical Reports Created" value={records.length} />
      </div>

      <section className="mt-8 rounded-2xl border border-border bg-card p-6 shadow-sm">
        <h2 className="text-xl font-semibold">Write Patient Diagnosis &amp; Prescription</h2>
        <form onSubmit={save} className="mt-4 grid gap-3">
          <input className={inp} placeholder="Patient Name" value={patient} onChange={(e) => setPatient(e.target.value)} />
          <input className={inp} placeholder="Doctor Name" value={doctor} onChange={(e) => setDoctor(e.target.value)} />
          <textarea className={`${inp} min-h-24`} placeholder="Diagnosis" value={diagnosis} onChange={(e) => setDiagnosis(e.target.value)} />
          <textarea className={`${inp} min-h-24`} placeholder="Prescription" value={prescription} onChange={(e) => setPrescription(e.target.value)} />
          <textarea className={`${inp} min-h-24`} placeholder="Treatment Plan" value={treatment} onChange={(e) => setTreatment(e.target.value)} />
          <button className="rounded-lg bg-emerald-500 px-4 py-2.5 font-medium text-white hover:bg-emerald-400">
            Save Medical Record
          </button>
        </form>
      </section>

      <section className="mt-8 rounded-2xl border border-border bg-card p-6 shadow-sm">
        <h2 className="text-xl font-semibold">All Patient Reports</h2>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-secondary text-secondary-foreground">
              <tr>
                {["Date", "Patient", "Doctor", "Diagnosis", "Prescription"].map((h) => (
                  <th key={h} className="px-3 py-2 text-left font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {records.map((r, i) => (
                <tr key={i} className="border-t border-border">
                  <td className="px-3 py-2">{r.date}</td>
                  <td className="px-3 py-2">{r.patient}</td>
                  <td className="px-3 py-2">{r.doctor}</td>
                  <td className="px-3 py-2">{r.diagnosis}</td>
                  <td className="px-3 py-2">{r.prescription}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}

/* ───────── Records ───────── */
function RecordsTab() {
  const { records } = useEMR();
  return (
    <>
      <h1 className="text-3xl font-bold">Patient Medical Records</h1>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-border bg-card p-4 shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-secondary-foreground">
            <tr>
              {["Date", "Patient", "Doctor", "Diagnosis", "Prescription", "Treatment"].map((h) => (
                <th key={h} className="px-3 py-2 text-left font-semibold">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {records.map((r, i) => (
              <tr key={i} className="border-t border-border">
                <td className="px-3 py-2">{r.date}</td>
                <td className="px-3 py-2">{r.patient}</td>
                <td className="px-3 py-2">{r.doctor}</td>
                <td className="px-3 py-2">{r.diagnosis}</td>
                <td className="px-3 py-2">{r.prescription}</td>
                <td className="px-3 py-2">{r.treatment}</td>
              </tr>
            ))}
            {records.length === 0 && (
              <tr><td colSpan={6} className="px-3 py-6 text-center text-muted-foreground">No records yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </>
  );
}

/* ───────── Admin ───────── */
function AdminTab() {
  const { appointments, records } = useEMR();
  const stats = [
    { value: 500, label: "Patients" },
    { value: 50, label: "Doctors" },
    { value: 1200 + appointments.length, label: "Appointments" },
    { value: 2500 + records.length, label: "Records" },
  ];
  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <button
          onClick={() => downloadAll(appointments, records)}
          className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow hover:bg-primary/90"
        >
          ⬇ Download All Data
        </button>
      </div>
      <p className="mt-2 text-sm text-muted-foreground">
        Exports appointments &amp; medical records as CSV plus a combined JSON file.
      </p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-card p-6 text-center shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
            <div className="text-4xl font-bold text-primary">{s.value}</div>
            <div className="mt-1 text-sm text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>
    </>
  );
}

/* ───────── Shared helpers ───────── */
function Field({ label, value, onChange, placeholder, type = "text" }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium">{label}</span>
      <input
        className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
        value={value}
        type={type}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </label>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 text-center shadow-sm">
      <div className="text-4xl font-bold text-primary">{value}</div>
      <div className="mt-1 text-sm text-muted-foreground">{label}</div>
    </div>
  );
}
