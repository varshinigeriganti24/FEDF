import { createContext, useContext, useMemo, useState, type ReactNode } from "react";

export interface Appointment {
  doctor: string;
  department: string;
  date: string;
  time: string;
  status: "Confirmed" | "Pending";
}

export interface MedicalRecord {
  date: string;
  patient: string;
  doctor: string;
  diagnosis: string;
  prescription: string;
  treatment: string;
}

interface EMRContextValue {
  patientName: string;
  setPatientName: (n: string) => void;
  appointments: Appointment[];
  addAppointment: (a: Appointment) => void;
  records: MedicalRecord[];
  addRecord: (r: MedicalRecord) => void;
}

const EMRContext = createContext<EMRContextValue | null>(null);

const seedAppointments: Appointment[] = [
  { doctor: "Dr. Priya Sharma", department: "Cardiology", date: "10-06-2026", time: "10:00 AM", status: "Confirmed" },
  { doctor: "Dr. Rajesh Kumar", department: "General Medicine", date: "11-06-2026", time: "11:30 AM", status: "Confirmed" },
  { doctor: "Dr. Anjali Reddy", department: "Dermatology", date: "12-06-2026", time: "02:00 PM", status: "Pending" },
];

const seedRecords: MedicalRecord[] = [
  {
    date: "10-06-2026",
    patient: "Rahul Kumar",
    doctor: "Dr. Priya Sharma",
    diagnosis: "Hypertension",
    prescription: "Amlodipine 5mg",
    treatment: "Daily medication & Diet Control",
  },
];

export function EMRProvider({ children }: { children: ReactNode }) {
  const [patientName, setPatientName] = useState("");
  const [appointments, setAppointments] = useState<Appointment[]>(seedAppointments);
  const [records, setRecords] = useState<MedicalRecord[]>(seedRecords);

  const value = useMemo<EMRContextValue>(
    () => ({
      patientName,
      setPatientName,
      appointments,
      addAppointment: (a) => setAppointments((prev) => [...prev, a]),
      records,
      addRecord: (r) => setRecords((prev) => [...prev, r]),
    }),
    [patientName, appointments, records],
  );

  return <EMRContext.Provider value={value}>{children}</EMRContext.Provider>;
}

export function useEMR() {
  const ctx = useContext(EMRContext);
  if (!ctx) throw new Error("useEMR must be used within EMRProvider");
  return ctx;
}

export const DOCTORS = [
  { dept: "Cardiology", name: "Dr. Priya Sharma", hours: "09:00 AM - 01:00 PM" },
  { dept: "General Medicine", name: "Dr. Rajesh Kumar", hours: "10:00 AM - 04:00 PM" },
  { dept: "Dermatology", name: "Dr. Anjali Reddy", hours: "11:00 AM - 05:00 PM" },
  { dept: "Orthopedics", name: "Dr. Vikram Singh", hours: "09:00 AM - 03:00 PM" },
  { dept: "Neurology", name: "Dr. Arun Kumar", hours: "01:00 PM - 07:00 PM" },
  { dept: "Pediatrics", name: "Dr. Meera Patel", hours: "08:00 AM - 02:00 PM" },
  { dept: "ENT", name: "Dr. Sneha Rao", hours: "09:00 AM - 02:00 PM" },
  { dept: "Dentistry", name: "Dr. Kiran Varma", hours: "10:00 AM - 06:00 PM" },
];