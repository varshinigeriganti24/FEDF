import type { Appointment, MedicalRecord } from "./emr-store";

function toCSV(rows: Array<Record<string, string | number>>): string {
  if (rows.length === 0) return "";
  const headers = Object.keys(rows[0]);
  const esc = (v: string | number) => {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [headers.join(","), ...rows.map((r) => headers.map((h) => esc(r[h])).join(","))].join("\n");
}

function downloadFile(name: string, content: string, type = "text/csv") {
  const blob = new Blob([content], { type: `${type};charset=utf-8;` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function downloadAll(appointments: Appointment[], records: MedicalRecord[]) {
  const stamp = new Date().toISOString().slice(0, 10);
  downloadFile(`appointments_${stamp}.csv`, toCSV(appointments as unknown as Array<Record<string, string | number>>));
  downloadFile(`medical_records_${stamp}.csv`, toCSV(records as unknown as Array<Record<string, string | number>>));

  const combined = {
    exportedAt: new Date().toISOString(),
    appointments,
    medicalRecords: records,
  };
  downloadFile(`emr_export_${stamp}.json`, JSON.stringify(combined, null, 2), "application/json");
}